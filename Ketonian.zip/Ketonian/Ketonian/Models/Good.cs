﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Models
{
  public class Good
  {
    public int GoodId { get; set; }

    //[Required(ErrorMessage = "Please enter song name")]
    public string Name { get; set; }

    //[Required(ErrorMessage ="Please enter a year")]
    //[Range(1900,2021,ErrorMessage ="Year must be between 1900 and 2021")]
    public string Calorie { get; set; }

    //[Required(ErrorMessage ="Please enter the rating")]
    //[Range(1,5,ErrorMessage ="Rating must be between 1 and 5")]
    public string Fat { get; set; }

    
  }
}
