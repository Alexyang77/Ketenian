﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Models
{
    public class BMIViewModel
    {
        public double Weight { get; set; }
        public double Height { get; set; }

        public double BMI { get; set; }
        public double BMICal()
        {
           
            BMI = Weight / (Height * Height);
            return BMI;
        }
    }
}
