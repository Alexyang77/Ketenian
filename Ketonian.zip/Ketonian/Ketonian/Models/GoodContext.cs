﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Models
{
  public class GoodContext : DbContext
  {
    public GoodContext(DbContextOptions<GoodContext> options)
      :base(options)
    {
    }

    public DbSet<Good> Goods { get; set; }
    public DbSet<ContactViewModel> Contacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      

      modelBuilder.Entity<Good>().HasData(
        new Good
        {
          GoodId = 1,
          Name = "Pork",
          Calorie = "330 calories",
          Fat = "29.3g",
          
        },
        new Good
        {
          GoodId = 2,
          Name = "Salmon",
          Calorie = "139 calories",
          Fat = "7.8g",
          
        },
        new Good
        {
          GoodId = 3,
          Name = "Steak",
          Calorie = "160 calories",
          Fat = "2.3g",

        }); 
    }
  }
}
