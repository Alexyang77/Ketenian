﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Models
{
    public class BMRViewModel
    {
        public double Weight { get; set; }
        public double Height { get; set; }

        public double Age { get; set; }

       
        public string Gender { get; set; }
        public double BMR{ get; set; }
        public double BMRMCal()
        {
            if (Gender == "M")
            {
                return BMR = 66.47 + (13.75 * Weight) + (5.003 * Height) - (6.755 * Age);
            }

            else
            {
                return BMR = 655.1 + (9.563 * Weight) + (1.85 * Height) - (4.676 * Age);
            }

           
        }
    }
}
