﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Ketonian.Migrations
{
    public partial class inital : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    ContactViewModelId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.ContactViewModelId);
                });

            migrationBuilder.CreateTable(
                name: "Goods",
                columns: table => new
                {
                    GoodId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Calorie = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Fat = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Goods", x => x.GoodId);
                });

            migrationBuilder.InsertData(
                table: "Goods",
                columns: new[] { "GoodId", "Calorie", "Fat", "Name" },
                values: new object[] { 1, "330 calories", "29.3g", "Pork" });

            migrationBuilder.InsertData(
                table: "Goods",
                columns: new[] { "GoodId", "Calorie", "Fat", "Name" },
                values: new object[] { 2, "139 calories", "7.8g", "Salmon" });

            migrationBuilder.InsertData(
                table: "Goods",
                columns: new[] { "GoodId", "Calorie", "Fat", "Name" },
                values: new object[] { 3, "160 calories", "2.3g", "Steak" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contacts");

            migrationBuilder.DropTable(
                name: "Goods");
        }
    }
}
