﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ketonian.Models;

namespace Ketonian.Controllers
{
    public class BMIController : Controller
    {
        [HttpGet]
        public IActionResult BMICal()
        {
            ViewBag.BMI = "";
            return View();
        }

        [HttpPost]
        public IActionResult BMICal(BMIViewModel bmi)
        {
            if (ModelState.IsValid)
            {
                ViewBag.BMI = bmi.BMICal();
            }
            else
            {
                ViewBag.BMI = "";
            }

            return View();
        }

    }
}

