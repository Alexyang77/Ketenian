﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Controllers
{
    public class FoodController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Goodtohave()
        {
            return View();
        }
        public IActionResult Shouldnothave()
        {
            return View();
        }
        public IActionResult Supplements()
        {
            return View();
        }
    }
}
