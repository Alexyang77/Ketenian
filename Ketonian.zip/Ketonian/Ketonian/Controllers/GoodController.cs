﻿using Ketonian.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Ketonian.Controllers
{
    public class GoodController : Controller
    {
    

        private GoodContext context { get; set; }

        public GoodController(GoodContext ctx)
        {
            context = ctx;
        }

        public IActionResult Good()
        {
            var goods = context.Goods.OrderBy(m => m.Name).ToList();
            return View(goods);
        }
    }
}
