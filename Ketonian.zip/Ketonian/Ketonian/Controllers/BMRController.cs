﻿using Ketonian.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Controllers
{
    public class BMRController : Controller
    {
        [HttpGet]
        public IActionResult BMRCal()
        {
            ViewBag.BMR = "";
            return View();
        }

        [HttpPost]
        public IActionResult BMRCal(BMRViewModel bmr)
        {
            if (ModelState.IsValid)
            {
                ViewBag.BMR = bmr.BMRMCal();
            }
            else
            {
                ViewBag.BMR = "";
            }

            return View();
        }
    }
}
