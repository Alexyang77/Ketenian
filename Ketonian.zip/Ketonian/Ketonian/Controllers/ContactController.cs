﻿using Ketonian.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ketonian.Controllers
{
    public class ContactController : Controller
    {
        private GoodContext contact { get; set; }

        public ContactController(GoodContext ctx)
        {
            contact = ctx;
        }
        [HttpGet]
        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(ContactViewModel contacts)
        {

            {
                if (ModelState.IsValid)
                {
                    contact.Update(contacts);
                    contact.SaveChanges(); 
                    ModelState.Clear();
                    ViewBag.Message = $"Massage sent Successfully!";
                    return View();

                   
                }
                else
                {
                    ViewBag.Message = "Please Try Again";

                    return View(contacts);
                }

                




           

            }

        }
    }
}
