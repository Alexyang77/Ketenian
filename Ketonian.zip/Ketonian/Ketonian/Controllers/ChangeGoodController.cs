﻿using Ketonian.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Ketonian.Controllers
{
    public class ChangeGoodController : Controller
    {
        private GoodContext changecontext { get; set; }

        public ChangeGoodController(GoodContext ctx)
        {
            changecontext = ctx;
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
        
            return View("Edit", new Good());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var good = changecontext.Goods.Find(id);
            return View(good);
        }

        [HttpPost]
        public IActionResult Edit(Good good)
        {
            if (ModelState.IsValid)
            {
                if (good.GoodId == 0)
                    changecontext.Goods.Add(good);
                else
                    changecontext.Goods.Update(good);

                changecontext.SaveChanges();
                return RedirectToAction("Good", "Good");
            }
            else
            {
                ViewBag.Action = good.GoodId == 0 ? "Add" : "Edit";
               
                return View(good);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var good = changecontext.Goods.Find(id);
            return View(good);
        }

        [HttpPost]
        public IActionResult Delete(Good good)
        {
            changecontext.Goods.Remove(good);
            changecontext.SaveChanges();
            return RedirectToAction("Good", "Good");
        }
    }
}

   
